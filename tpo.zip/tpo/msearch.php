<?php
$fullname=$_POST['fullname'];
$department=$_POST['department'];

echo $fullname;
echo $department;
?>